<?php header('Content-type: text/cache-manifest'); ?>
CACHE MANIFEST
# Testing cache manifest file V1
CACHE:
http://fog.ccsf.edu/~cdasilva/cnit133m/example6/tartanscm.html
http://fog.ccsf.edu/~cdasilva/cnit133m/example6/tartans/icons/abercrombie.png
http://fog.ccsf.edu/~cdasilva/cnit133m/example6/tartans/icons/cameron-hunting.png
http://fog.ccsf.edu/~cdasilva/cnit133m/example6/tartans/icons/cameron.png
http://fog.ccsf.edu/~cdasilva/cnit133m/example6/tartans/icons/davidson.png
http://fog.ccsf.edu/~cdasilva/cnit133m/example6/tartans/icons/napier.png
http://fog.ccsf.edu/~cdasilva/cnit133m/example6/tartans/tartans.css
http://code.jquery.com/mobile/1.2.0-alpha.1/jquery.mobile-1.2.0-alpha.1.min.css
http://code.jquery.com/jquery-1.7.2.min.js
http://code.jquery.com/mobile/1.2.0-alpha.1/jquery.mobile-1.2.0-alpha.1.min.js
